from time import sleep

import RPi.GPIO as GPIO 

GPIO.setmode(GPIO.BOARD)
cap_corba=12
cap_tfa7a=16
dcy=15
verin=11
motor=13
C=0
K=0
GPIO.setup(cap_corba,GPIO.IN,pull_up_dpwn=GPIO.PUD_UP)
GPIO.setup(cap_tfa7a,GPIO.IN,pull_up_dpwn=GPIO.PUD_UP)
GPIO.setup(dcy,GPIO.IN,pull_up_dpwn=GPIO.PUD_UP)
GPIO.setup(verin,GPIO.OUT)
GPIO.setup(motor,GPIO.OUT)


if GPIO.INPUT(dcy)==0 :
    GPIO.OUTPUT(motor,True)
    while 1 :
        if GPIO.INPUT(cap_tfa7a)==0 :
            
            if output_data == 1 :
                GPIO.OUTPUT(verin,True)
                sleep(0.1)
                GPIO.OUTPUT(verin,False)
                K = K+1
            else :
                GPIO.OUTPUT(verin,False)
                C=C+1

    if GPIO.INPUT(dcy)==1: break           