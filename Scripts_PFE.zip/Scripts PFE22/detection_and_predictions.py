import cv2 
import tensorflow.keras as keras
import numpy as np
import tensorflow as tf
import cvlib as cv
from cvlib.object_detection import draw_bbox
from time import sleep
import RPi.GPIO as GPIO 

#getting ready for the image import

webcam = cv2.VideoCapture(0)

interpreter = tf.lite.Interpreter(model_path="model.tflite")

interpreter.allocate_tensors()

input_details = interpreter.get_input_details()

output_details = interpreter.get_output_details()

#preprossesing images functions

def image_resize(image, height, inter = cv2.INTER_AREA):

    dim = None

    (h, w) = image.shape[:2]

    r = height / float(h)

    dim = (int(w * r), height)

    resized = cv2.resize(image, dim, interpolation = inter)

    return resized


def cropTo(img):

    size = 350

    height, width = img.shape[:2]

    sideCrop = (width - 350) // 2

    return img[:,sideCrop:(width - sideCrop)]


# initialisations of statistical parameters

C=0

K=0

#configuring inputs and outputs

GPIO.setmode(GPIO.BOARD)

dcy=15

verin=11

motor=13

#setup 

GPIO.setup(dcy,GPIO.IN,pull_up_dpwn=GPIO.PUD_UP)
GPIO.setup(verin,GPIO.OUT)
GPIO.setup(motor,GPIO.OUT)

GPIO.output(verin,False)
GPIO.output(motor,False)


#the cycle

if GPIO.input(dcy)==1 :    #if dcy is pressed

    GPIO.output(motor,True) 

    while True:

        _, frame = webcam.read()        # collecting images

        bbox, label, conf = cv.detect_common_objects(frame, confidence=0.40, model='yolov3-tiny')                      

        #if apple exists then classify:

        for x in label:


            if x == 'apple':

                #same as the cropping process in TM2

                img = image_resize(img, height=350)

                img = cropTo(img)
        
                image = tf.image.convert_image_dtype(img, dtype=tf.float32)

                image = tf.image.resize(image, [350,350]) 

                image = tf.expand_dims(image, axis=0)

                interpreter.set_tensor(input_details[0]['index'], image)

                interpreter.invoke()

                #Run the predictions
  
                output_data = interpreter.get_tensor(output_details[0]['index'])

                output_data = np.argmax(output_data)

                #printing the results
 
                print(output_data)
#################################################################################
            #if result = rotten (1)

                if output_data == 1 :        #push the supposed rotten apple

                    sleep(0.1)               #Delay
                
                    GPIO.output(verin,True)      # push in and out
                    GPIO.output(verin,False)

                    K = K+1             #statistical parameter(num of rotten apples)
#####################################################################################
            #if result = fresh (0)

                else :            #keep the supposed fresh apple

                    GPIO.output(verin,False)

                    C = C+1        #statistical parameter(num of fresh apples)

#######################################################################################

        #elif label==(''):       #if nothing appears then continue
        
           #bruh=1

            else:                #if something other than an apple appears then turnoff motor and alarm the user
        
                GPIO.output(motor,False)

                print (" something is SUS ")  #sus? 



        #if GPIO.input(dcy)==1: break        #if dcy button is pressed then shutdown          
            







