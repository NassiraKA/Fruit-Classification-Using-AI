import cv2
import tensorflow.keras as keras
import numpy as np
import tensorflow as tf
import cvlib as cv
from cvlib.object_detection import draw_bbox
from time import sleep
#import RPi.GPIO as GPIO 
from pfe_functions import image_resize , cropTo , classification_function 




# initialisations of statistical parameters

C=0

K=0

#configuring inputs and outputs
    
dcy=15

verin=11

motor=13

buzzer = 16

#GPIO.setmode(GPIO.BOARD)

#gpio_setup()


#add an if statment if u want lol 

webcam = cv2.VideoCapture(0)


while True:
        sleep(1)

        _, frame = webcam.read()        # collecting images

        bbox, label, conf = cv.detect_common_objects(frame, confidence=0.40, model='yolov3-tiny')    
        output_image = draw_bbox(frame, bbox, label, conf)
        img = image_resize(frame, height=350)
        frame = cropTo(img)

        cv2.imshow('webcam', frame)
        key = cv2.waitKey(20)
        if key == 27: # exit on ESC
         break               
       
        print(label)

        if len(label)==0:
            print("") 
        
        else:                    #if apple exists then classify:

            for x in label:

                if x == 'apple' and len(label)==1:
                    
                    output_data = classification_function(frame)
                    print(output_data)

                #if result = rotten (1)

                    if output_data == 1 :        #push the supposed rotten apple

                        sleep(0.1)               #Delay
                    
                        print("verin out") #GPIO.output(verin,True)      # push in and out
                        sleep(1)
                        print("verin in") #GPIO.output(verin,False)

                        K = K+1             #statistical parameter(num of rotten apples)
    
                #if result = fresh (0)

                    else :            #keep the supposed fresh apple

                        print("verin IN") #GPIO.output(verin,False)

                        C = C+1        #statistical parameter(num of fresh apples)

    
                
                else:                #if something other than an apple appears then turnoff motor and alarm the user
            
                    print("stop le moteur") #GPIO.output(motor,False)
                                            #GPIO.output(buzzer,True)
                                            #sleep(0.5)
                                            #GPIO.output(buzzer,False)
                
            #if GPIO.input(dcy)==1: break        #if emergency button is pressed then shutdown                          