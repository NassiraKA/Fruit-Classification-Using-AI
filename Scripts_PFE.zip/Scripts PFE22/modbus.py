
from pyModbusTCP.server import ModbusServer, DataBank
from time import sleep
from final_script_iguess import output_data, label


# Create an instance of ModbusServer
server = ModbusServer("127.0.0.1", 12345, no_block=True)

try:
    print("Start server...")
    server.start()
    print("Server is online")
    
    while True:

        DataBank.set_words(0, [label])
        
        sleep(0.5)

except:
    print("Shutdown server ...")
    server.stop()
    print("Server is offline")