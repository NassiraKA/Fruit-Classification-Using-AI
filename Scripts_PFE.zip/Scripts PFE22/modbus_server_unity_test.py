from pyModbusTCP.server import ModbusServer, DataBank
from time import sleep

server = ModbusServer("127.0.0.1", 12345, no_block=True)
server.start()

while True :

    server.read_holding_registers(0)
    sleep(0.5)
    server.read_holding_registers(1)
