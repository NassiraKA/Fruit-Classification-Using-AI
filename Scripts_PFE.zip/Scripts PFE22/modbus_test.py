from pyModbusTCP.client import ModbusClient
from time import sleep
client = ModbusClient("192.168.137.54", 12345)

client.open()
print("success")


while True:
    
    if client.read_holding_registers(0) == [0]:
            print("aucun object detecté")
    elif client.read_holding_registers(0) == [1]:
            print("pomme detecté")
    else:
            print("INTRUS!")
    print("")

    if client.read_holding_registers(1) == [1]:
            print("pomme pourris")
    elif client.read_holding_registers(1) == [0] :
            print("pomme fraiche") 

    print("")     
            
    if client.read_holding_registers(4) == [1]:
        print("VERRIN OUT")
    

 
    print("")
    
    sleep(0.5)
    print("le nombre de pomme fraiche est:")
    print(client.read_holding_registers(2))

    print("")        
    sleep(0.5)
    print("le nombre de pomme pourris est:")
    print(client.read_holding_registers(3))
    
    sleep(0.5)

    
    print("")
    print("reload")
    sleep(1.5)
    print("")