import cv2
import tensorflow.keras as keras
import numpy as np
import tensorflow as tf
import cvlib as cv
from cvlib.object_detection import draw_bbox
from time import sleep
import time
import RPi.GPIO as GPIO 
from pfe_functions import image_resize , cropTo , classification_function , gpio_setup
from pyModbusTCP.server import ModbusServer, DataBank


# Create an instance of ModbusServer
server = ModbusServer("192.168.137.54", 12345, no_block=True)
server.start()

webcam = cv2.VideoCapture(0)

# initialisations of statistical parameters

C=0

K=0

dist =0.40

x=0.2

y=0.14

#configuring inputs and outputs
    
dcy=15

verin=22

motor=18

buzzer = 16

cap= 37

GPIO_TRIGGER = 40

GPIO_ECHO = 24

GPIO.setwarnings(False)

GPIO.setmode(GPIO.BOARD)

    #setup 

GPIO.setup(dcy,GPIO.IN,pull_up_down=GPIO.PUD_UP)

GPIO.setup(cap,GPIO.IN,pull_up_down=GPIO.PUD_UP)

GPIO.setup(GPIO_ECHO,GPIO.IN,pull_up_down=GPIO.PUD_UP)

    #GPIO.setup(ar,GPIO.IN,pull_up_down=GPIO.PUD_UP)
    #GPIO.setup(dcy,GPIO.OUT)

GPIO.setup(verin,GPIO.OUT)
GPIO.setup(motor,GPIO.OUT)
GPIO.setup(buzzer,GPIO.OUT)
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)


GPIO.output(verin,False)
GPIO.output(motor,False)
GPIO.output(buzzer,False)
GPIO.output(GPIO_TRIGGER,False)


#add an if statment if u want lol 



while True:
            if GPIO.input(dcy)==0: break        #if emergency button is pressed then shutdown
            object = 0
            output_data = 2
            #if GPIO.input(dcy)==0:
        
            GPIO.output(GPIO_TRIGGER,False)           
            GPIO.output(verin,False)
            GPIO.output(motor,False)
            GPIO.output(buzzer,False)

            _, frame = webcam.read()        # collecting images

            bbox, label, conf = cv.detect_common_objects(frame, confidence=0.40, model='yolov3-tiny')    
            output_image = draw_bbox(frame, bbox, label, conf)
            img = image_resize(frame, height=350)
            frame = cropTo(img)

            cv2.imshow('webcam', frame)
            key = cv2.waitKey(20)
            if key == 27: # exit on ESC
             break               
           
            print(label)

            if len(label)==0:
                print("")
                object = 0
                DataBank.set_words(0, [object, output_data, K, C])
                GPIO.output(motor,False)
                GPIO.output(buzzer,False)
                
            else:                    #if apple exists then classify:

                for x in label:

                    if x == 'apple' and len(label)==1:
                        
                        GPIO.output(buzzer,False)
                        object = 1
                        output_data = classification_function(frame)
                        print(output_data)
                        DataBank.set_words(0, [object, output_data, K, C])

                    #if result = rotten (1)

                        if output_data == 1 :#and GPIO.input(cap)==37 :        #push the supposed rotten apple
                            GPIO.output(motor,True)
                            sleep(0.1)               #Delay
                            print("rotten")
                            dist=0.40
                            
                            """ while  dist>y:
                                dist=1
                                sleep(0.5)
                                 # set Trigger to HIGH
                                GPIO.output(GPIO_TRIGGER, True)
                             
                                # set Trigger after 0.01ms to LOW
                                time.sleep(0.00001)
                                GPIO.output(GPIO_TRIGGER, False)
                             
                                StartTime = time.time()
                                StopTime = time.time()
                             
                                # save StartTime
                                while GPIO.input(GPIO_ECHO) == 0:
                                    StartTime = time.time()
                             
                                # save time of arrival
                                while GPIO.input(GPIO_ECHO) == 1:
                                    StopTime = time.time()
                             
                                # time difference between start and arrival
                                TimeElapsed = StopTime - StartTime
                                # multiply with the sonic speed (34300 cm/s)
                                # and divide by 2, because there and back
                                dist = (TimeElapsed * 343) / 2
                                #print (dist) """

                            #print(dist)

                            print("verin out")      
                            GPIO.output(verin,True)     # push in and out
                            verin = 1
                            DataBank.set_words(0, [object, output_data, K, C, verin])
                            verin = 0
                            sleep(2)
                            print("verin in")
                            GPIO.output(verin,False)
                            GPIO.output(motor,False)
                        
                            
                           

                            K = K+1             #statistical parameter(num of rotten apples)
                            DataBank.set_words(0, [object, output_data, K, C, verin])
        



                            #if result = fresh (0)                                 
       
                          

                        else :            #keep the supposed fresh apple

                            print("verin IN")
                            GPIO.output(verin,False)

                            C = C+1        #statistical parameter(num of fresh apples)
                            DataBank.set_words(0, [object, output_data, K, C, verin])

                    
                    
                    else:                #if something other than an apple appears then turnoff motor and alarm the user
                
                        print("stop le moteur")
                        GPIO.output(motor,True)
                        GPIO.output(buzzer,True)
                        sleep(1)
                        GPIO.output(buzzer,False)
                        sleep(1)
                        object = 2
                        DataBank.set_words(0, [object, output_data, K, C, verin])
                        
                        
                    
            