from black import out
import cv2
import matplotlib.pyplot as plt
import cvlib as cv
from cvlib.object_detection import draw_bbox
from time import sleep
webcam = cv2.VideoCapture(0)

while(True):

    _, frame = webcam.read()


    bbox, label, conf = cv.detect_common_objects(frame, confidence=0.5, nms_thresh=0.3, model='yolov3-tiny', enable_gpu=False)
    output_image = draw_bbox(frame, bbox, label, conf)
    print(label)

    for x in label:

        if x == 'apple':
            print("im in the loop bro")
    
    #plt.imshow(output_image)
    #plt.show()
    cv2.imshow('webcam', frame)
    key = cv2.waitKey(20)
    if key == 27: # exit on ESC
        break 
