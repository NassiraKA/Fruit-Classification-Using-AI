import cv2 
import tensorflow.keras as keras
import numpy as np
import tensorflow as tf
import cvlib as cv
from cvlib.object_detection import draw_bbox
from time import sleep
#import RPi.GPIO as GPIO 


def image_resize(image, height, inter = cv2.INTER_AREA):

    dim = None

    (h, w) = image.shape[:2]

    r = height / float(h)

    dim = (int(w * r), height)

    resized = cv2.resize(image, dim, interpolation = inter)

    return resized

def cropTo(img):

    size = 350

    height, width = img.shape[:2]

    sideCrop = (width - 350) // 2

    return img[:,sideCrop:(width - sideCrop)]


def classification_function(img):

    interpreter = tf.lite.Interpreter(model_path="model.tflite")

    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()

    output_details = interpreter.get_output_details()

        
    image = tf.image.convert_image_dtype(img, dtype=tf.float32)

    image = tf.image.resize(image, [350,350]) 

    image = tf.expand_dims(image, axis=0)

    interpreter.set_tensor(input_details[0]['index'], image)

    interpreter.invoke()

     #Run the predictions
  
    output_data = interpreter.get_tensor(output_details[0]['index'])

    output_data = np.argmax(output_data)

    #printing the results
    
    return output_data

#
#def gpio_setup():
    

    dcy=15

    verin=11

    motor=13

    buzzer = 16

    #setup 

    #GPIO.setup(dcy,GPIO.IN,pull_up_down=GPIO.PUD_UP)
    GPIO.setup(dcy,GPIO.OUT)
    GPIO.setup(verin,GPIO.OUT)
    GPIO.setup(motor,GPIO.OUT)
    GPIO.setup(buzzer,GPIO.OUT)

    GPIO.output(verin,False)
    

def ascii(text):
    ascii_values = [ord(character) for character in text]
    return ascii_values

def init():
    no_object = 0
    output_data = 2
    alert = 0
    