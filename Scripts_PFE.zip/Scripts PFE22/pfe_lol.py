import os
import glob
from sklearn.model_selection import train_test_split
import shutil
from tensorflow.keras.layers import Conv2D, Input, Dense, MaxPool2D, BatchNormalization, GlobalAvgPool2D
from tensorflow.keras import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras import Model
import tensorflow as tf



def split_data(path_to_data, path_to_save_train, path_to_save_val, split_size=0.1):

    folders = os.listdir(path_to_data)

    for folder in folders:

        full_path = os.path.join(path_to_data, folder)
        images_paths = glob.glob(os.path.join(full_path, '*.png'))

        x_train, x_val = train_test_split(images_paths, test_size=split_size)

        for x in x_train:

            path_to_folder = os.path.join(path_to_save_train, folder)

            if not os.path.isdir(path_to_folder):
                os.makedirs(path_to_folder)

            shutil.copy(x, path_to_folder)

        for x in x_val:

            path_to_folder = os.path.join(path_to_save_val, folder)
            if not os.path.isdir(path_to_folder):
                os.makedirs(path_to_folder)

            shutil.copy(x, path_to_folder)      

def fruit_model(nbr_classes):

    my_input = Input(shape=(350,350,3))


    x = Conv2D(32, (3,3), activation='relu')(my_input)
    x = MaxPool2D()(x)
    x = BatchNormalization()(x)

    x = Conv2D(64, (3,3), activation='relu')(x)
    x = MaxPool2D()(x)
    x = BatchNormalization()(x)

    x = Conv2D(128, (3,3), activation='relu')(x)
    x = MaxPool2D()(x)
    x = BatchNormalization()(x)

    # x = Flatten()(x)
    x = GlobalAvgPool2D()(x)
    x = Dense(128, activation='relu')(x)
    x = Dense(nbr_classes, activation='softmax')(x)

    return Model(inputs=my_input, outputs=x)

def create_generators(batch_size, train_data_path, val_data_path, test_data_path):

    train_preprocessor = ImageDataGenerator(
        rescale = 1 / 255,
        
    )

    test_preprocessor = ImageDataGenerator(
        rescale = 1 / 255,
    )

    train_generator = train_preprocessor.flow_from_directory(
        train_data_path,
        class_mode="categorical",
        target_size=(350,350),
        color_mode='rgb',
        shuffle=True,
        batch_size=batch_size
    )

    val_generator = test_preprocessor.flow_from_directory(
        val_data_path,
        class_mode="categorical",
        target_size=(350,350),
        color_mode="rgb",
        shuffle=False,
        batch_size=batch_size,
    )

    test_generator = test_preprocessor.flow_from_directory(
        test_data_path,
        class_mode="categorical",
        target_size=(350,350),
        color_mode="rgb",
        shuffle=False,
        batch_size=batch_size,
    )
    return train_generator, val_generator, test_generator





#split_data(path_to_data = path_to_data , path_to_save_train = path_to_save_train , path_to_save_val = path_to_save_val, split_size=0.1)

path_to_train = "C:\\Users\\AY_TERRASSI\\Desktop\\MY_DATASET(apples)\\train_new"
path_to_val = "C:\\Users\\AY_TERRASSI\\Desktop\\MY_DATASET(apples)\\val_new" 
path_to_test = "C:\\Users\\AY_TERRASSI\\Desktop\\MY_DATASET(apples)\\test"
batch_size = 16
#10
epochs = 15

train_generator, val_generator, test_generator = create_generators(batch_size=batch_size, train_data_path=path_to_train, val_data_path=path_to_val, test_data_path = path_to_test)

nbr_classes = train_generator.num_classes

#
path_to_save_model = './My_Models'


ckpt_saver = ModelCheckpoint(
    path_to_save_model,
    monitor="val_accuracy",
    mode='max',
    save_best_only=True,
    save_freq='epoch',
    verbose=1
    )


#partie conception du model TRAINING

if False:


  model = fruit_model(nbr_classes)

  model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
  model.fit(train_generator, batch_size=batch_size , epochs=epochs, validation_data=val_generator, callbacks=[ckpt_saver])

#partie test

if True :
    model = tf.keras.models.load_model('./My_Models')
    model.summary()
   
    print("evaluating test")
    model.evaluate(test_generator)

