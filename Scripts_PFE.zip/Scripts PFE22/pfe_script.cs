using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UModbusTCP;

public class pfe_script : MonoBehaviour
{   
    InputField 

    // Start is called before the first frame update
    void Start()
    {
        field = GameObject.Find("TextInputField").GetComponent<InputField>();
        
        Hum = GameObject.Find("InputField1").GetComponent<InputField>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
