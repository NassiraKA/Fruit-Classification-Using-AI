import tensorflow as tf
import numpy as np



def predict_with_model(model, imgpath):

    image = tf.io.read_file(imgpath)
    image = tf.image.decode_png(image, channels=3)
    image = tf.image.convert_image_dtype(image, dtype=tf.float32)
    image = tf.image.resize(image, [350,350]) # (60,60,3)
    image = tf.expand_dims(image, axis=0) # (1,60,60,3)

    predictions = model.predict(image) # [0.005, 0.00003, 0.99, 0.00 ....]
    predictions = np.argmax(predictions) # 2

    return predictions



if __name__=="__main__":

    img_path = "C:\\Users\\AY_TERRASSI\\Desktop\\MY_DATASET(apples)\\test\\rottenapples\\rotated_by_15_Screen Shot 2018-06-07 at 2.25.26 PM.png"
 

    model = tf.keras.models.load_model('./My_Models')
    prediction = predict_with_model(model, img_path)

    print(prediction)