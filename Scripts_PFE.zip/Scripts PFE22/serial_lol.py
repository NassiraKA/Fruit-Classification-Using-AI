import serial

sus = serial.Serial(port = 'COM1', baudrate = 9600, timeout=0.01)

#declaration des variables
adresse = 0
func_code = 1
data = 402
#trame = [adresse , func_code, data] 
trame = [0x01,0x03,0x10,0x66,0x00,0x02]


#CRC fucntion
def crc(buf):


    temp=0xFFFF
    
    for x in range(0,len(buf)):
        
        temp=temp ^ buf[x]

        for x in range(1,9):

            flag =temp & 0x0001
            temp=temp >> 1
            if (flag) : temp=temp ^ 0xA001
    
    
    temp2=temp >> 8
    temp=(temp << 8) | temp2
    temp &= 0xFFFF
    return(temp)



PFCRC = crc(trame)//256 
PfCRC = crc(trame)-256*PFCRC

print(PFCRC)    
print(PfCRC)
trame.append(PfCRC)
trame.append(PFCRC)

print(trame)
for i in range(0,len(trame)):

    sus.write(bytes(trame[i],'ascii'))