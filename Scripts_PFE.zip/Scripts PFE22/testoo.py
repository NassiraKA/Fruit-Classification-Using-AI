import cv2 
import tensorflow.keras as keras
import numpy as np
import tensorflow as tf
import cvlib as cv
from cvlib.object_detection import draw_bbox
from time import sleep

from pfe_functions import image_resize , cropTo , classification_function 
#getting ready for the image import

webcam = cv2.VideoCapture(0)


# initialisations of statistical parameters

C=0

K=0

#configuring inputs and outputs
    
dcy=15

verin=11

motor=13



#the cycle



while True:

        _, frame = webcam.read()        # collecting images

        bbox, label, conf = cv.detect_common_objects(frame, confidence=0.40, model='yolov3-tiny') 
        output_image = draw_bbox(frame, bbox, label, conf)
        cv2.imshow('webcam', frame)
        key = cv2.waitKey(20)
        if key == 27: # exit on ESC
         break 
                     

        #if apple exists then classify:

        for x in label:


            if x == 'apple':

               
               output_data = classification_function(frame)
               print(output_data)

            else:
                break